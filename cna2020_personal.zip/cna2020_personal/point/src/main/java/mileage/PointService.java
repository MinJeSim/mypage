package mileage;

public interface PointService {
    Point getProductById(Long id);
}

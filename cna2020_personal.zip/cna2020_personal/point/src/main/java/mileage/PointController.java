package mileage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
public class PointController {
//    @Autowired
//    private PointRepository pointRepository;
//
//    @PatchMapping(value = "/points")
//    public Point save(Point point) {
//        System.out.println("test");
//        return pointRepository.save(point);
//    }
}
